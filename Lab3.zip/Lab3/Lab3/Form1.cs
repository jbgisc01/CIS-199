﻿//Grading ID C5463
//Lab3 
//Due Date: 02/13/22
//CIS 199-03
//This is a program that takes the radius of a sphere and calculates the Diameter, Surface Area, and Volume
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Lab3 : Form
    {
        public Lab3()
        {
            InitializeComponent();
        }
          // Event Handler for the Calculation button
        private void CalcBtn_Click(object sender, EventArgs e) 
        {
            // Define Variables
            double Radius;// Radius input
            double Diameter; //Diameter input
            double Area;//Area Input
            double Volume; //Volume input


            Radius = double.Parse(RadiusTxt.Text); //Convert the radius textbox to allow an input
            Diameter = 2 * Radius; // Calculation for Diameter
            OutputLbl_Dia.Text = $"{Diameter:f2}"; // Output for Diameter
            Area = 4 * Math.PI * Math.Pow(Radius, 2); // Calculation for Area
            SA_Out.Text = $"{Area:f2}"; // Output for Surface Area
            Volume = (4 * Math.PI * Math.Pow(Radius, 3)) / 3; // Calculation for Volume
            Lbl_OutVol.Text = $"{Volume:F2}"; // Output for Volume




        }

    }
}
