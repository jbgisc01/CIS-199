﻿namespace Lab2real
{
    partial class Lab2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MPriceLbl = new System.Windows.Forms.Label();
            this.MealPriceTxt = new System.Windows.Forms.TextBox();
            this.Tip15 = new System.Windows.Forms.Label();
            this.Tip18 = new System.Windows.Forms.Label();
            this.Tip20 = new System.Windows.Forms.Label();
            this.Output15Lbl = new System.Windows.Forms.Label();
            this.OutputLbl_18 = new System.Windows.Forms.Label();
            this.OutputLbl_20 = new System.Windows.Forms.Label();
            this.CalcTipBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // MPriceLbl
            // 
            this.MPriceLbl.AutoSize = true;
            this.MPriceLbl.Location = new System.Drawing.Point(26, 46);
            this.MPriceLbl.Name = "MPriceLbl";
            this.MPriceLbl.Size = new System.Drawing.Size(97, 13);
            this.MPriceLbl.TabIndex = 0;
            this.MPriceLbl.Text = "Enter Price of Meal";
            // 
            // MealPriceTxt
            // 
            this.MealPriceTxt.AcceptsReturn = true;
            this.MealPriceTxt.Location = new System.Drawing.Point(163, 46);
            this.MealPriceTxt.Name = "MealPriceTxt";
            this.MealPriceTxt.Size = new System.Drawing.Size(100, 20);
            this.MealPriceTxt.TabIndex = 1;
            // 
            // Tip15
            // 
            this.Tip15.AutoSize = true;
            this.Tip15.Location = new System.Drawing.Point(96, 97);
            this.Tip15.Name = "Tip15";
            this.Tip15.Size = new System.Drawing.Size(30, 13);
            this.Tip15.TabIndex = 2;
            this.Tip15.Text = "15 %";
            // 
            // Tip18
            // 
            this.Tip18.AutoSize = true;
            this.Tip18.Location = new System.Drawing.Point(96, 151);
            this.Tip18.Name = "Tip18";
            this.Tip18.Size = new System.Drawing.Size(30, 13);
            this.Tip18.TabIndex = 3;
            this.Tip18.Text = "18 %";
            // 
            // Tip20
            // 
            this.Tip20.AutoSize = true;
            this.Tip20.Location = new System.Drawing.Point(96, 207);
            this.Tip20.Name = "Tip20";
            this.Tip20.Size = new System.Drawing.Size(30, 13);
            this.Tip20.TabIndex = 4;
            this.Tip20.Text = "20 %";
            // 
            // Output15Lbl
            // 
            this.Output15Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Output15Lbl.Location = new System.Drawing.Point(163, 96);
            this.Output15Lbl.Name = "Output15Lbl";
            this.Output15Lbl.Size = new System.Drawing.Size(100, 23);
            this.Output15Lbl.TabIndex = 5;
            // 
            // OutputLbl_18
            // 
            this.OutputLbl_18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OutputLbl_18.Location = new System.Drawing.Point(163, 150);
            this.OutputLbl_18.Name = "OutputLbl_18";
            this.OutputLbl_18.Size = new System.Drawing.Size(100, 23);
            this.OutputLbl_18.TabIndex = 6;
            // 
            // OutputLbl_20
            // 
            this.OutputLbl_20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OutputLbl_20.Location = new System.Drawing.Point(163, 206);
            this.OutputLbl_20.Name = "OutputLbl_20";
            this.OutputLbl_20.Size = new System.Drawing.Size(100, 23);
            this.OutputLbl_20.TabIndex = 7;
            // 
            // CalcTipBtn
            // 
            this.CalcTipBtn.Location = new System.Drawing.Point(176, 268);
            this.CalcTipBtn.Name = "CalcTipBtn";
            this.CalcTipBtn.Size = new System.Drawing.Size(75, 23);
            this.CalcTipBtn.TabIndex = 8;
            this.CalcTipBtn.Text = "Calculate Tip ";
            this.CalcTipBtn.UseVisualStyleBackColor = true;
            this.CalcTipBtn.Click += new System.EventHandler(this.CalcTipBtn_Click);
            // 
            // Lab2
            // 
            this.AcceptButton = this.CalcTipBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 361);
            this.Controls.Add(this.CalcTipBtn);
            this.Controls.Add(this.OutputLbl_20);
            this.Controls.Add(this.OutputLbl_18);
            this.Controls.Add(this.Output15Lbl);
            this.Controls.Add(this.Tip20);
            this.Controls.Add(this.Tip18);
            this.Controls.Add(this.Tip15);
            this.Controls.Add(this.MealPriceTxt);
            this.Controls.Add(this.MPriceLbl);
            this.Name = "Lab2";
            this.Text = "Lab2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MPriceLbl;
        private System.Windows.Forms.TextBox MealPriceTxt;
        private System.Windows.Forms.Label Tip15;
        private System.Windows.Forms.Label Tip18;
        private System.Windows.Forms.Label Tip20;
        private System.Windows.Forms.Label Output15Lbl;
        private System.Windows.Forms.Label OutputLbl_18;
        private System.Windows.Forms.Label OutputLbl_20;
        private System.Windows.Forms.Button CalcTipBtn;
    }
}

