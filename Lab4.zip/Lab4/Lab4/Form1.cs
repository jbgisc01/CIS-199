﻿// Grading ID: C5463
// CIS 199-03
//Lab 4
//February 27, 2022
//This is a program that keeps track of how many students have been accepted and denied based off their input of their GPA and Test Score
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Lab4 : Form
    {
        int AccTotal = 0; //To continuously keep track of the # accepted
        int RejTotal = 0; // To keep track of the # rejected

        public Lab4()
        {
            InitializeComponent();
        }

        private void DecBtn_Click(object sender, EventArgs e)
        {
            // Declaring of variables used
            float GPA; 
            float TestScore = 0;

            if (float.TryParse(GpaTxt.Text, out GPA) && (float.TryParse(TstScTxt.Text, out TestScore))); // initial if statement that runs Tryparse for GPA and Test Score
            {
                if ((GPA >= 0.0 && GPA <= 4.0) && (TestScore >= 0 && TestScore <= 100)) // If statement that sets parameters on GPA and Test Score
                {
                    if ((GPA >= 3.0 && TestScore >= 60) || (GPA < 3.0 && TestScore >= 80)) // If statement that sets the scores needed to enter the university 
                    {
                        AccTotal = AccTotal + 1; //adds to the accepted total
                        this.OutputAcc_Lbl.Text = AccTotal.ToString(); // converts the accepted valvue to be displayed
                        
                        MessageBox.Show("Accepted"); // output if accepted
                    }
                    else
                    {
                        RejTotal = RejTotal + 1; // adds to the rejected total 

                        this.RejOut_Lbl.Text = RejTotal.ToString(); //displays the rejected total 
                        
                        MessageBox.Show("Denied"); // output if denied
                    }


                }
                else
                    MessageBox.Show("Enter a Valid Score"); // output if invalid inputs are used
            }
            
        }  
    }
}
