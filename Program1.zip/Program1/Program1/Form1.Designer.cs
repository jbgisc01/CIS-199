﻿namespace Program1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.HeaderLbl = new System.Windows.Forms.Label();
            this.FrontLenLbl = new System.Windows.Forms.Label();
            this.SideLenLbl = new System.Windows.Forms.Label();
            this.HeightLbl = new System.Windows.Forms.Label();
            this.FrontLenTxt = new System.Windows.Forms.TextBox();
            this.SideLenTxt = new System.Windows.Forms.TextBox();
            this.HeightTxt = new System.Windows.Forms.TextBox();
            this.WindowNumLbl = new System.Windows.Forms.Label();
            this.NumWindowTxt = new System.Windows.Forms.TextBox();
            this.DryWallSqFt_Lbl = new System.Windows.Forms.Label();
            this.LaborSqFtTxt = new System.Windows.Forms.TextBox();
            this.DryWallSqFTTxt = new System.Windows.Forms.TextBox();
            this.CostLaborSqFt_Lbl = new System.Windows.Forms.Label();
            this.NeededSqFtLbl = new System.Windows.Forms.Label();
            this.OutPut_SqFtNeed = new System.Windows.Forms.Label();
            this.ExtraPercentLbl = new System.Windows.Forms.Label();
            this.Extra10OutputLbl = new System.Windows.Forms.Label();
            this.CostLaborLbl = new System.Windows.Forms.Label();
            this.LaborCost_Output = new System.Windows.Forms.Label();
            this.MatCost_Lbl = new System.Windows.Forms.Label();
            this.Output_MatCost = new System.Windows.Forms.Label();
            this.CostTot_Lbl = new System.Windows.Forms.Label();
            this.TotCost_Output = new System.Windows.Forms.Label();
            this.CalcBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // HeaderLbl
            // 
            this.HeaderLbl.AutoSize = true;
            this.HeaderLbl.Location = new System.Drawing.Point(135, 18);
            this.HeaderLbl.Name = "HeaderLbl";
            this.HeaderLbl.Size = new System.Drawing.Size(184, 13);
            this.HeaderLbl.TabIndex = 0;
            this.HeaderLbl.Text = "Dry Wall and Window Cost Calculator";
            // 
            // FrontLenLbl
            // 
            this.FrontLenLbl.AutoSize = true;
            this.FrontLenLbl.Location = new System.Drawing.Point(72, 53);
            this.FrontLenLbl.Name = "FrontLenLbl";
            this.FrontLenLbl.Size = new System.Drawing.Size(103, 13);
            this.FrontLenLbl.TabIndex = 1;
            this.FrontLenLbl.Text = "Length of Front ( ft ):";
            // 
            // SideLenLbl
            // 
            this.SideLenLbl.AutoSize = true;
            this.SideLenLbl.Location = new System.Drawing.Point(72, 95);
            this.SideLenLbl.Name = "SideLenLbl";
            this.SideLenLbl.Size = new System.Drawing.Size(100, 13);
            this.SideLenLbl.TabIndex = 2;
            this.SideLenLbl.Text = "Length of Side ( ft ):";
            // 
            // HeightLbl
            // 
            this.HeightLbl.AutoSize = true;
            this.HeightLbl.Location = new System.Drawing.Point(96, 133);
            this.HeightLbl.Name = "HeightLbl";
            this.HeightLbl.Size = new System.Drawing.Size(65, 13);
            this.HeightLbl.TabIndex = 3;
            this.HeightLbl.Text = "Height ( ft ): ";
            // 
            // FrontLenTxt
            // 
            this.FrontLenTxt.Location = new System.Drawing.Point(219, 50);
            this.FrontLenTxt.Name = "FrontLenTxt";
            this.FrontLenTxt.Size = new System.Drawing.Size(100, 20);
            this.FrontLenTxt.TabIndex = 4;
            // 
            // SideLenTxt
            // 
            this.SideLenTxt.Location = new System.Drawing.Point(219, 88);
            this.SideLenTxt.Name = "SideLenTxt";
            this.SideLenTxt.Size = new System.Drawing.Size(100, 20);
            this.SideLenTxt.TabIndex = 5;
            // 
            // HeightTxt
            // 
            this.HeightTxt.Location = new System.Drawing.Point(219, 130);
            this.HeightTxt.Name = "HeightTxt";
            this.HeightTxt.Size = new System.Drawing.Size(100, 20);
            this.HeightTxt.TabIndex = 6;
            // 
            // WindowNumLbl
            // 
            this.WindowNumLbl.AutoSize = true;
            this.WindowNumLbl.Location = new System.Drawing.Point(31, 175);
            this.WindowNumLbl.Name = "WindowNumLbl";
            this.WindowNumLbl.Size = new System.Drawing.Size(144, 13);
            this.WindowNumLbl.TabIndex = 7;
            this.WindowNumLbl.Text = "Window? ( 1 = YES, 0 = No )";
            // 
            // NumWindowTxt
            // 
            this.NumWindowTxt.Location = new System.Drawing.Point(219, 172);
            this.NumWindowTxt.Name = "NumWindowTxt";
            this.NumWindowTxt.Size = new System.Drawing.Size(100, 20);
            this.NumWindowTxt.TabIndex = 8;
            // 
            // DryWallSqFt_Lbl
            // 
            this.DryWallSqFt_Lbl.AutoSize = true;
            this.DryWallSqFt_Lbl.Location = new System.Drawing.Point(28, 221);
            this.DryWallSqFt_Lbl.Name = "DryWallSqFt_Lbl";
            this.DryWallSqFt_Lbl.Size = new System.Drawing.Size(145, 13);
            this.DryWallSqFt_Lbl.TabIndex = 9;
            this.DryWallSqFt_Lbl.Text = "Cost of Dry Wall Per Sq Feet:";
            // 
            // LaborSqFtTxt
            // 
            this.LaborSqFtTxt.Location = new System.Drawing.Point(219, 258);
            this.LaborSqFtTxt.Name = "LaborSqFtTxt";
            this.LaborSqFtTxt.Size = new System.Drawing.Size(100, 20);
            this.LaborSqFtTxt.TabIndex = 10;
            // 
            // DryWallSqFTTxt
            // 
            this.DryWallSqFTTxt.Location = new System.Drawing.Point(219, 218);
            this.DryWallSqFTTxt.Name = "DryWallSqFTTxt";
            this.DryWallSqFTTxt.Size = new System.Drawing.Size(100, 20);
            this.DryWallSqFTTxt.TabIndex = 11;
            // 
            // CostLaborSqFt_Lbl
            // 
            this.CostLaborSqFt_Lbl.AutoSize = true;
            this.CostLaborSqFt_Lbl.Location = new System.Drawing.Point(41, 261);
            this.CostLaborSqFt_Lbl.Name = "CostLaborSqFt_Lbl";
            this.CostLaborSqFt_Lbl.Size = new System.Drawing.Size(135, 13);
            this.CostLaborSqFt_Lbl.TabIndex = 12;
            this.CostLaborSqFt_Lbl.Text = "Cost of Labor Per Sq Feet: ";
            // 
            // NeededSqFtLbl
            // 
            this.NeededSqFtLbl.AutoSize = true;
            this.NeededSqFtLbl.Location = new System.Drawing.Point(58, 300);
            this.NeededSqFtLbl.Name = "NeededSqFtLbl";
            this.NeededSqFtLbl.Size = new System.Drawing.Size(118, 13);
            this.NeededSqFtLbl.TabIndex = 13;
            this.NeededSqFtLbl.Text = "Total Sq Feet Needed: ";
            // 
            // OutPut_SqFtNeed
            // 
            this.OutPut_SqFtNeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OutPut_SqFtNeed.Location = new System.Drawing.Point(219, 299);
            this.OutPut_SqFtNeed.Name = "OutPut_SqFtNeed";
            this.OutPut_SqFtNeed.Size = new System.Drawing.Size(100, 23);
            this.OutPut_SqFtNeed.TabIndex = 14;
            // 
            // ExtraPercentLbl
            // 
            this.ExtraPercentLbl.AutoSize = true;
            this.ExtraPercentLbl.Location = new System.Drawing.Point(107, 343);
            this.ExtraPercentLbl.Name = "ExtraPercentLbl";
            this.ExtraPercentLbl.Size = new System.Drawing.Size(54, 13);
            this.ExtraPercentLbl.TabIndex = 15;
            this.ExtraPercentLbl.Text = "10% Extra";
            // 
            // Extra10OutputLbl
            // 
            this.Extra10OutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Extra10OutputLbl.Location = new System.Drawing.Point(219, 342);
            this.Extra10OutputLbl.Name = "Extra10OutputLbl";
            this.Extra10OutputLbl.Size = new System.Drawing.Size(100, 23);
            this.Extra10OutputLbl.TabIndex = 16;
            // 
            // CostLaborLbl
            // 
            this.CostLaborLbl.AutoSize = true;
            this.CostLaborLbl.Location = new System.Drawing.Point(108, 382);
            this.CostLaborLbl.Name = "CostLaborLbl";
            this.CostLaborLbl.Size = new System.Drawing.Size(64, 13);
            this.CostLaborLbl.TabIndex = 17;
            this.CostLaborLbl.Text = "Labor Cost: ";
            // 
            // LaborCost_Output
            // 
            this.LaborCost_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LaborCost_Output.Location = new System.Drawing.Point(219, 381);
            this.LaborCost_Output.Name = "LaborCost_Output";
            this.LaborCost_Output.Size = new System.Drawing.Size(100, 23);
            this.LaborCost_Output.TabIndex = 18;
            // 
            // MatCost_Lbl
            // 
            this.MatCost_Lbl.AutoSize = true;
            this.MatCost_Lbl.Location = new System.Drawing.Point(96, 421);
            this.MatCost_Lbl.Name = "MatCost_Lbl";
            this.MatCost_Lbl.Size = new System.Drawing.Size(71, 13);
            this.MatCost_Lbl.TabIndex = 19;
            this.MatCost_Lbl.Text = "Material Cost:";
            // 
            // Output_MatCost
            // 
            this.Output_MatCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Output_MatCost.Location = new System.Drawing.Point(219, 420);
            this.Output_MatCost.Name = "Output_MatCost";
            this.Output_MatCost.Size = new System.Drawing.Size(100, 23);
            this.Output_MatCost.TabIndex = 20;
            // 
            // CostTot_Lbl
            // 
            this.CostTot_Lbl.AutoSize = true;
            this.CostTot_Lbl.Location = new System.Drawing.Point(108, 474);
            this.CostTot_Lbl.Name = "CostTot_Lbl";
            this.CostTot_Lbl.Size = new System.Drawing.Size(58, 13);
            this.CostTot_Lbl.TabIndex = 21;
            this.CostTot_Lbl.Text = "Total Cost:";
            // 
            // TotCost_Output
            // 
            this.TotCost_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotCost_Output.Location = new System.Drawing.Point(219, 464);
            this.TotCost_Output.Name = "TotCost_Output";
            this.TotCost_Output.Size = new System.Drawing.Size(100, 23);
            this.TotCost_Output.TabIndex = 22;
            // 
            // CalcBtn
            // 
            this.CalcBtn.Location = new System.Drawing.Point(204, 541);
            this.CalcBtn.Name = "CalcBtn";
            this.CalcBtn.Size = new System.Drawing.Size(124, 23);
            this.CalcBtn.TabIndex = 23;
            this.CalcBtn.Text = "Calculate Estimate";
            this.CalcBtn.UseVisualStyleBackColor = true;
            this.CalcBtn.Click += new System.EventHandler(this.CalcBtn_Click);
            // 
            // Program1
            // 
            this.AcceptButton = this.CalcBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 597);
            this.Controls.Add(this.CalcBtn);
            this.Controls.Add(this.TotCost_Output);
            this.Controls.Add(this.CostTot_Lbl);
            this.Controls.Add(this.Output_MatCost);
            this.Controls.Add(this.MatCost_Lbl);
            this.Controls.Add(this.LaborCost_Output);
            this.Controls.Add(this.CostLaborLbl);
            this.Controls.Add(this.Extra10OutputLbl);
            this.Controls.Add(this.ExtraPercentLbl);
            this.Controls.Add(this.OutPut_SqFtNeed);
            this.Controls.Add(this.NeededSqFtLbl);
            this.Controls.Add(this.CostLaborSqFt_Lbl);
            this.Controls.Add(this.DryWallSqFTTxt);
            this.Controls.Add(this.LaborSqFtTxt);
            this.Controls.Add(this.DryWallSqFt_Lbl);
            this.Controls.Add(this.NumWindowTxt);
            this.Controls.Add(this.WindowNumLbl);
            this.Controls.Add(this.HeightTxt);
            this.Controls.Add(this.SideLenTxt);
            this.Controls.Add(this.FrontLenTxt);
            this.Controls.Add(this.HeightLbl);
            this.Controls.Add(this.SideLenLbl);
            this.Controls.Add(this.FrontLenLbl);
            this.Controls.Add(this.HeaderLbl);
            this.Name = "Program1";
            this.Text = " ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label HeaderLbl;
        private System.Windows.Forms.Label FrontLenLbl;
        private System.Windows.Forms.Label SideLenLbl;
        private System.Windows.Forms.Label HeightLbl;
        private System.Windows.Forms.TextBox FrontLenTxt;
        private System.Windows.Forms.TextBox SideLenTxt;
        private System.Windows.Forms.TextBox HeightTxt;
        private System.Windows.Forms.Label WindowNumLbl;
        private System.Windows.Forms.TextBox NumWindowTxt;
        private System.Windows.Forms.Label DryWallSqFt_Lbl;
        private System.Windows.Forms.TextBox LaborSqFtTxt;
        private System.Windows.Forms.TextBox DryWallSqFTTxt;
        private System.Windows.Forms.Label CostLaborSqFt_Lbl;
        private System.Windows.Forms.Label NeededSqFtLbl;
        private System.Windows.Forms.Label OutPut_SqFtNeed;
        private System.Windows.Forms.Label ExtraPercentLbl;
        private System.Windows.Forms.Label Extra10OutputLbl;
        private System.Windows.Forms.Label CostLaborLbl;
        private System.Windows.Forms.Label LaborCost_Output;
        private System.Windows.Forms.Label MatCost_Lbl;
        private System.Windows.Forms.Label Output_MatCost;
        private System.Windows.Forms.Label CostTot_Lbl;
        private System.Windows.Forms.Label TotCost_Output;
        private System.Windows.Forms.Button CalcBtn;
    }
}

