﻿//Program 1
//Grading ID: C5463
//Cis 199-03
//This is a program that calculates the estimated fees for a room
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Program1 : Form
    {
        public Program1()
        {
            InitializeComponent();
        }

        private void CalcBtn_Click(object sender, EventArgs e)
        {
            //Define Variables
            const double ExtraFactor = 1.1;
            const double WindowFee = 100.00;

            double frontLength;
            double height;
            double sideLength;
            double LaborCostperSqFt;
            double DrywallCostSqFeet;
            double TotalFeet;
            double laborcost;
            double ExtraRate;
            double matCOST;
            double windowfee;
            double TotalCost; 
            int windowNum;

            frontLength = double.Parse(FrontLenTxt.Text);
            sideLength = double.Parse(SideLenTxt.Text);
            height = double.Parse(HeightTxt.Text);
            DrywallCostSqFeet = double.Parse(DryWallSqFTTxt.Text);
            LaborCostperSqFt = double.Parse(LaborSqFtTxt.Text);
            windowNum = int.Parse(NumWindowTxt.Text);
            //Calculations 
            TotalFeet = 2 * frontLength * height + 2 * sideLength * height + frontLength * sideLength; // Total feet calculations
            OutPut_SqFtNeed.Text = $"{TotalFeet:C}"; // output for the sqFt needed
            windowfee = WindowFee * windowNum; // window fee calculation
            laborcost = LaborCostperSqFt * TotalFeet * ExtraFactor; // labor cost calculation
            LaborCost_Output.Text = $"{laborcost:C}"; // output for labor cost 
            ExtraRate = TotalFeet * ExtraFactor; // calculation for extra rate 
            Extra10OutputLbl.Text = $"{ExtraRate}"; // output for extra rate
            matCOST = DrywallCostSqFeet * TotalFeet * ExtraFactor; // calculation for material cost
            Output_MatCost.Text = $"{matCOST:c}"; // output for material cost
            TotalCost = laborcost + matCOST + WindowFee; // calculation for total cost
            TotCost_Output.Text = $"{TotalCost:C}"; // Outout for total cost
        }
    }
}
