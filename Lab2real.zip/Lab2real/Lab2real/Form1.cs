﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2real
{
    public partial class Lab2 : Form
    {
        public Lab2()
        {
            InitializeComponent();
        }

        private void CalcTipBtn_Click(object sender, EventArgs e)
        {
            double Meal;
            double Tip1;
            double Tip2;
            double Tip3;


            Meal = double.Parse(MealPriceTxt.Text); // conversion from Meal Price as text to allow input
            Tip1 = Meal * 0.15; // calculation for 15% tip
            Output15Lbl.Text = $"{Tip1:C}"; // Output for 15% Tip
            Tip2 = Meal * 0.18; // Calculation for 18% Tip
            OutputLbl_18.Text = $"{Tip2:C}"; // display the 18% Tip
            Tip3 = Meal * 0.2; // CalCulation for 20% Tip
            OutputLbl_20 .Text= $"{Tip3:C}"; // Display the 20% Tip 
        }
    }
}
