﻿namespace Lab4
{
    partial class Lab4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OutputAcc_Lbl = new System.Windows.Forms.Label();
            this.Accd_Lbl = new System.Windows.Forms.Label();
            this.Tst_Lbl = new System.Windows.Forms.Label();
            this.Gpa_Lbl = new System.Windows.Forms.Label();
            this.TstScTxt = new System.Windows.Forms.TextBox();
            this.GpaTxt = new System.Windows.Forms.TextBox();
            this.DecBtn = new System.Windows.Forms.Button();
            this.RejTotal_Lbl = new System.Windows.Forms.Label();
            this.RejOut_Lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // OutputAcc_Lbl
            // 
            this.OutputAcc_Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OutputAcc_Lbl.Location = new System.Drawing.Point(189, 211);
            this.OutputAcc_Lbl.Name = "OutputAcc_Lbl";
            this.OutputAcc_Lbl.Size = new System.Drawing.Size(22, 23);
            this.OutputAcc_Lbl.TabIndex = 0;
            // 
            // Accd_Lbl
            // 
            this.Accd_Lbl.AutoSize = true;
            this.Accd_Lbl.Location = new System.Drawing.Point(67, 212);
            this.Accd_Lbl.Name = "Accd_Lbl";
            this.Accd_Lbl.Size = new System.Drawing.Size(86, 13);
            this.Accd_Lbl.TabIndex = 1;
            this.Accd_Lbl.Text = "Total Accepted: ";
            // 
            // Tst_Lbl
            // 
            this.Tst_Lbl.AutoSize = true;
            this.Tst_Lbl.Location = new System.Drawing.Point(67, 136);
            this.Tst_Lbl.Name = "Tst_Lbl";
            this.Tst_Lbl.Size = new System.Drawing.Size(112, 13);
            this.Tst_Lbl.TabIndex = 3;
            this.Tst_Lbl.Text = "Admission Test Score:";
            // 
            // Gpa_Lbl
            // 
            this.Gpa_Lbl.AutoSize = true;
            this.Gpa_Lbl.Location = new System.Drawing.Point(94, 86);
            this.Gpa_Lbl.Name = "Gpa_Lbl";
            this.Gpa_Lbl.Size = new System.Drawing.Size(85, 13);
            this.Gpa_Lbl.TabIndex = 5;
            this.Gpa_Lbl.Text = "Enter Your GPA:";
            // 
            // TstScTxt
            // 
            this.TstScTxt.Location = new System.Drawing.Point(225, 133);
            this.TstScTxt.Name = "TstScTxt";
            this.TstScTxt.Size = new System.Drawing.Size(100, 20);
            this.TstScTxt.TabIndex = 6;
            // 
            // GpaTxt
            // 
            this.GpaTxt.Location = new System.Drawing.Point(225, 83);
            this.GpaTxt.Name = "GpaTxt";
            this.GpaTxt.Size = new System.Drawing.Size(100, 20);
            this.GpaTxt.TabIndex = 7;
            // 
            // DecBtn
            // 
            this.DecBtn.Location = new System.Drawing.Point(201, 274);
            this.DecBtn.Name = "DecBtn";
            this.DecBtn.Size = new System.Drawing.Size(124, 23);
            this.DecBtn.TabIndex = 8;
            this.DecBtn.Text = "Admission Decision";
            this.DecBtn.UseVisualStyleBackColor = true;
            this.DecBtn.Click += new System.EventHandler(this.DecBtn_Click);
            // 
            // RejTotal_Lbl
            // 
            this.RejTotal_Lbl.AutoSize = true;
            this.RejTotal_Lbl.Location = new System.Drawing.Point(261, 212);
            this.RejTotal_Lbl.Name = "RejTotal_Lbl";
            this.RejTotal_Lbl.Size = new System.Drawing.Size(80, 13);
            this.RejTotal_Lbl.TabIndex = 9;
            this.RejTotal_Lbl.Text = "Total Rejected:";
            // 
            // RejOut_Lbl
            // 
            this.RejOut_Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RejOut_Lbl.Location = new System.Drawing.Point(372, 212);
            this.RejOut_Lbl.Name = "RejOut_Lbl";
            this.RejOut_Lbl.Size = new System.Drawing.Size(30, 22);
            this.RejOut_Lbl.TabIndex = 10;
            // 
            // Lab4
            // 
            this.AcceptButton = this.DecBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 450);
            this.Controls.Add(this.RejOut_Lbl);
            this.Controls.Add(this.RejTotal_Lbl);
            this.Controls.Add(this.DecBtn);
            this.Controls.Add(this.GpaTxt);
            this.Controls.Add(this.TstScTxt);
            this.Controls.Add(this.Gpa_Lbl);
            this.Controls.Add(this.Tst_Lbl);
            this.Controls.Add(this.Accd_Lbl);
            this.Controls.Add(this.OutputAcc_Lbl);
            this.Name = "Lab4";
            this.Text = "Lab4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label OutputAcc_Lbl;
        private System.Windows.Forms.Label Accd_Lbl;
        private System.Windows.Forms.Label Tst_Lbl;
        private System.Windows.Forms.Label Gpa_Lbl;
        private System.Windows.Forms.TextBox TstScTxt;
        private System.Windows.Forms.TextBox GpaTxt;
        private System.Windows.Forms.Button DecBtn;
        private System.Windows.Forms.Label RejTotal_Lbl;
        private System.Windows.Forms.Label RejOut_Lbl;
    }
}

