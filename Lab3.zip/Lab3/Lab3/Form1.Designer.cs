﻿namespace Lab3
{
    partial class Lab3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Lab3));
            this.SphereRadiusLbl = new System.Windows.Forms.Label();
            this.RadiusTxt = new System.Windows.Forms.TextBox();
            this.Diameter_Lbl = new System.Windows.Forms.Label();
            this.OutputLbl_Dia = new System.Windows.Forms.Label();
            this.SurfaceA_Lbl = new System.Windows.Forms.Label();
            this.SA_Out = new System.Windows.Forms.Label();
            this.VolumeLbl = new System.Windows.Forms.Label();
            this.Lbl_OutVol = new System.Windows.Forms.Label();
            this.CalcBtn = new System.Windows.Forms.Button();
            this.Sphere_img1 = new System.Windows.Forms.PictureBox();
            this.Sphere_img2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Sphere_img1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Sphere_img2)).BeginInit();
            this.SuspendLayout();
            // 
            // SphereRadiusLbl
            // 
            this.SphereRadiusLbl.AutoSize = true;
            this.SphereRadiusLbl.Location = new System.Drawing.Point(168, 42);
            this.SphereRadiusLbl.Name = "SphereRadiusLbl";
            this.SphereRadiusLbl.Size = new System.Drawing.Size(92, 13);
            this.SphereRadiusLbl.TabIndex = 0;
            this.SphereRadiusLbl.Text = "Radius of Sphere:";
            // 
            // RadiusTxt
            // 
            this.RadiusTxt.AcceptsReturn = true;
            this.RadiusTxt.Location = new System.Drawing.Point(268, 42);
            this.RadiusTxt.Name = "RadiusTxt";
            this.RadiusTxt.Size = new System.Drawing.Size(100, 20);
            this.RadiusTxt.TabIndex = 1;
            // 
            // Diameter_Lbl
            // 
            this.Diameter_Lbl.AutoSize = true;
            this.Diameter_Lbl.Location = new System.Drawing.Point(21, 187);
            this.Diameter_Lbl.Name = "Diameter_Lbl";
            this.Diameter_Lbl.Size = new System.Drawing.Size(52, 13);
            this.Diameter_Lbl.TabIndex = 2;
            this.Diameter_Lbl.Text = "Diameter:";
            // 
            // OutputLbl_Dia
            // 
            this.OutputLbl_Dia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OutputLbl_Dia.Location = new System.Drawing.Point(96, 186);
            this.OutputLbl_Dia.Name = "OutputLbl_Dia";
            this.OutputLbl_Dia.Size = new System.Drawing.Size(100, 23);
            this.OutputLbl_Dia.TabIndex = 3;
            // 
            // SurfaceA_Lbl
            // 
            this.SurfaceA_Lbl.AutoSize = true;
            this.SurfaceA_Lbl.Location = new System.Drawing.Point(9, 225);
            this.SurfaceA_Lbl.Name = "SurfaceA_Lbl";
            this.SurfaceA_Lbl.Size = new System.Drawing.Size(72, 13);
            this.SurfaceA_Lbl.TabIndex = 4;
            this.SurfaceA_Lbl.Text = "Surface Area:";
            // 
            // SA_Out
            // 
            this.SA_Out.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SA_Out.Location = new System.Drawing.Point(96, 224);
            this.SA_Out.Name = "SA_Out";
            this.SA_Out.Size = new System.Drawing.Size(100, 23);
            this.SA_Out.TabIndex = 5;
            // 
            // VolumeLbl
            // 
            this.VolumeLbl.AutoSize = true;
            this.VolumeLbl.Location = new System.Drawing.Point(21, 268);
            this.VolumeLbl.Name = "VolumeLbl";
            this.VolumeLbl.Size = new System.Drawing.Size(45, 13);
            this.VolumeLbl.TabIndex = 6;
            this.VolumeLbl.Text = "Volume:";
            // 
            // Lbl_OutVol
            // 
            this.Lbl_OutVol.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lbl_OutVol.Location = new System.Drawing.Point(96, 267);
            this.Lbl_OutVol.Name = "Lbl_OutVol";
            this.Lbl_OutVol.Size = new System.Drawing.Size(100, 23);
            this.Lbl_OutVol.TabIndex = 7;
            // 
            // CalcBtn
            // 
            this.CalcBtn.Location = new System.Drawing.Point(278, 100);
            this.CalcBtn.Name = "CalcBtn";
            this.CalcBtn.Size = new System.Drawing.Size(75, 23);
            this.CalcBtn.TabIndex = 8;
            this.CalcBtn.Text = "Calculate";
            this.CalcBtn.UseVisualStyleBackColor = true;
            this.CalcBtn.Click += new System.EventHandler(this.CalcBtn_Click);
            // 
            // Sphere_img1
            // 
            this.Sphere_img1.Image = ((System.Drawing.Image)(resources.GetObject("Sphere_img1.Image")));
            this.Sphere_img1.Location = new System.Drawing.Point(12, 12);
            this.Sphere_img1.Name = "Sphere_img1";
            this.Sphere_img1.Size = new System.Drawing.Size(150, 150);
            this.Sphere_img1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Sphere_img1.TabIndex = 9;
            this.Sphere_img1.TabStop = false;
            // 
            // Sphere_img2
            // 
            this.Sphere_img2.Image = ((System.Drawing.Image)(resources.GetObject("Sphere_img2.Image")));
            this.Sphere_img2.Location = new System.Drawing.Point(218, 191);
            this.Sphere_img2.Name = "Sphere_img2";
            this.Sphere_img2.Size = new System.Drawing.Size(150, 150);
            this.Sphere_img2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Sphere_img2.TabIndex = 10;
            this.Sphere_img2.TabStop = false;
            // 
            // Lab3
            // 
            this.AcceptButton = this.CalcBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 361);
            this.Controls.Add(this.Sphere_img2);
            this.Controls.Add(this.Sphere_img1);
            this.Controls.Add(this.CalcBtn);
            this.Controls.Add(this.Lbl_OutVol);
            this.Controls.Add(this.VolumeLbl);
            this.Controls.Add(this.SA_Out);
            this.Controls.Add(this.SurfaceA_Lbl);
            this.Controls.Add(this.OutputLbl_Dia);
            this.Controls.Add(this.Diameter_Lbl);
            this.Controls.Add(this.RadiusTxt);
            this.Controls.Add(this.SphereRadiusLbl);
            this.Name = "Lab3";
            this.Text = "Lab3";
            ((System.ComponentModel.ISupportInitialize)(this.Sphere_img1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Sphere_img2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SphereRadiusLbl;
        private System.Windows.Forms.TextBox RadiusTxt;
        private System.Windows.Forms.Label Diameter_Lbl;
        private System.Windows.Forms.Label OutputLbl_Dia;
        private System.Windows.Forms.Label SurfaceA_Lbl;
        private System.Windows.Forms.Label SA_Out;
        private System.Windows.Forms.Label VolumeLbl;
        private System.Windows.Forms.Label Lbl_OutVol;
        private System.Windows.Forms.Button CalcBtn;
        private System.Windows.Forms.PictureBox Sphere_img1;
        private System.Windows.Forms.PictureBox Sphere_img2;
    }
}

